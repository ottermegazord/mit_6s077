Data taken from:

https://www.kaggle.com/borismarjanovic/price-volume-data-for-all-us-stocks-etfs/data

Get more from there and play with it.
