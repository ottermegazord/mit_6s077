import pandas as pd


def convert_to_logdif(stockp):
    retval = stockp.copy();
    for jj in range(len(stockp)):
        if (jj == 0):
            retval[jj] = np.nan;
        else:
            retval[jj] = np.log(stockp[jj]) - np.log(stockp[jj-1]);
    
    return retval.iloc[1:];

#
# Load two stocks, convert them into daily log-growth data and merge into common time frame;
# Example: 
# 1. d = load_two_stocks(second_file = 'spy.us.txt', second_col='SPY');
#    print(d.iloc[0],d.iloc[-1]);
# 2. d2015 = d.select(lambda ts: ts.year == 2015);
#    d2015.describe();
#    plt.hist([d2015['GOOG_logdiff'], d2015['SPY_logdiff']], bins=30);
#   note: to get example ts do ts=pd._libs.Timestamp('2016');
#   cool data: SP500 grew 1.5%, google 45%, but this is not significant!
#   
#
def load_two_stocks(first_file = 'goog.us.txt', first_col = 'GOOG', second_file = 'fb.us.txt', second_col = 'FB', silent=False):
#    path = '/home/tcp/Science/Classes/6.DataSci/data/Stocks/';
    path = '';
    goog = pd.DataFrame.from_csv(path + first_file);
    fb = pd.DataFrame.from_csv(path + second_file);

    goog_dif = convert_to_logdif(goog['Open']);
    fb_dif = convert_to_logdif(fb['Open']);

    joined = pd.concat([goog_dif, goog['Open'], fb_dif, fb['Open']], axis=1, join='inner');
    joined.columns = [first_col+'_logdiff', first_col+'_open', second_col+'_logdiff', second_col+'_open'];
    joined['delta_logdiff'] = joined[first_col+'_logdiff'] - joined[second_col+'_logdiff'];

    if not silent:
        # Also do paired t-test
        tstat = np.mean(joined['delta_logdiff'])/np.std(joined['delta_logdiff']) * np.sqrt(len(joined));
        print('T-stat = %g (%s - %s).\nP-values:\n  Null %s = %s: p = %g\n  Null %s > %s: p = %g\n' % 
                (tstat, first_col, second_col,
                        second_col, first_col, 2*sp.stats.norm.sf(np.abs(tstat)), 
                        second_col, first_col, sp.stats.norm.sf(tstat)));

        # And do it for 2015 only
        j2015 = joined.select(lambda ts: ts.year == 2015);
        tstat = np.mean(j2015['delta_logdiff'])/np.std(j2015['delta_logdiff']) * np.sqrt(len(j2015));
        print('T-stat (2015) = %g (%s - %s).\nP-values:\n  Null %s = %s: p = %g\n  Null %s > %s: p = %g\n' % 
                (tstat, first_col, second_col,
                        second_col, first_col, 2*sp.stats.norm.sf(np.abs(tstat)), 
                        second_col, first_col, sp.stats.norm.sf(tstat)));
    
    return joined;

def plot_data():
    first_file = 'goog.us.txt';
    first_col = 'GOOG';
    second_file = 'spy.us.txt'; 
    second_col = 'SPY';

    d = load_two_stocks(first_file, first_col, second_file, second_col, silent=True);
    d2 = d.select(lambda ts: ts.year == 2015);

    gbase = d2.iloc[0].GOOG_open;
    goog = d2.GOOG_open / gbase;
    sbase = d2.iloc[0].SPY_open;
    spy = d2.SPY_open/sbase;

    gdiff = d2.GOOG_logdiff;
    sdiff = d2.SPY_logdiff;

    plt.ioff();
    goog.plot(kind='line', legend=True, linewidth=2);
    spy.plot(kind='line', legend=True, linewidth=2);
    #plt.savefig('../../figs/fin_base.svg', bbox_inches='tight');
    plt.close();

    gdiff.plot(kind='kde', legend=True, linewidth=2);
    sdiff.plot(kind='kde', legend=True, linewidth=2);
    #plt.savefig('../../figs/fin_kde.svg', bbox_inches='tight');
    plt.close();
    
    gdiff.plot(kind='hist', bins=40, legend=True, linewidth=2);
    sdiff.plot(kind='hist', bins=40, legend=True, linewidth=2);
    #plt.savefig('../../figs/fin_hist.svg', bbox_inches='tight');
    plt.close();
    
    print('First and last entries (of %d total):' % (len(d2),) );
    print(d2.iloc[0]);
    print(d2.iloc[-1]);
    
    tstat = np.mean(d2['delta_logdiff'])/np.std(d2['delta_logdiff']) * np.sqrt(len(d2));
    print('T-stat (2015) = %g (%s - %s).\nP-values:\n  Null %s = %s: p = %g' % 
            (tstat, first_col, second_col,
                    second_col, first_col, 2*sp.stats.norm.sf(np.abs(tstat))));

    return d2;    


