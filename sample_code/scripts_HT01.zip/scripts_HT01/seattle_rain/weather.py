import pandas as pd
import matplotlib as mplt

df = pd.DataFrame.from_csv('seattleWeather_1948-2017.csv');

def do_rand_sample(df=df, size=100, N_hist = 2000):
    N = 5;
    print('Printing random subsample (size=%d) z-stats:\n' % (size,));
    for jj in range(N):
        df_rand = df.sample(size); 
        z = sum(df_rand['RAIN'] - 1/2)/np.sqrt(len(df_rand)/4); 
        print('Sample %d: z-score = %g, two-sided p-val = %g\n' % (jj, z, 2*sp.stats.norm.sf(np.abs(z))));

    print('Computing histogram...\n');

    N_runs = 0;
    N_nans = 0;
    temp_hist = [];
    while N_hist > 0:
        df_rand = df.sample(size); 
        z = sum(df_rand['RAIN'] - 1/2)/np.sqrt(len(df_rand)/4);
        if(not np.isnan(z)):
            temp_hist.append(z);
            N_hist -= 1;
        else:
            N_nans += 1;
        N_runs += 1

    print('Done calculating hist: N_runs = %d, N_nans = %d' % (N_runs, N_nans));

    return temp_hist;


def plot_1(samp_size):

    plt.ioff();
    hist1 = do_rand_sample(df, size=samp_size, N_hist = 5000);

    xmin = np.min(hist1);
    xmax = np.max(hist1);
    xmax = max(xmax, 0.1);

    ax = plt.figure().gca();
    hh = ax.hist(hist1, bins='auto', color='blue', normed=True);
    line = matplotlib.lines.Line2D(xdata=[0,0], ydata=[0,np.max(hh[0])], color='black', linewidth=3, linestyle='dashed');
    plt.xlim([xmin,xmax]);
    ax.add_line(line);
    plt.title('Sample-size = %d' % (samp_size,));
    #plt.savefig('../../figs/srain_%da.svg' % (samp_size,), bbox_inches='tight');
    gkde = sp.stats.gaussian_kde(hist1);
    Xs = np.linspace(xmin, xmax, 140);
    ax.plot(Xs, gkde.pdf(Xs), color='red', linewidth=3);
    #plt.savefig('../../figs/srain_%db.svg' % (samp_size,), bbox_inches='tight');
    plt.close();
    

def plot_all():
    plot_1(10);
    plot_1(100);
    plot_1(1000);

