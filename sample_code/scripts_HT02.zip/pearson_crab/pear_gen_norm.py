import pandas as pd

df = pd.DataFrame.from_csv('pearson_crab.csv');
bin_ends = np.array(df.index);
bin_counts = np.array(df.FREQ);
bin_begs = np.zeros_like(bin_ends);
bin_begs[1:] = bin_ends[0:-1];
N = int(np.sum(bin_counts));
emp_mean = np.sum(bin_counts * bin_ends)/N;
emp_var = np.sum(bin_counts * ((bin_ends - emp_mean)**2) )/(N-1);
print('Pearson crab: mean = %g, std.dev. = %g' %( emp_mean, np.sqrt(emp_var)));

# Merge first 5 bins and last 5 bins:
nbin_ends = np.copy(bin_ends[4:-4]); nbin_ends[-1] = np.inf;
nbin_begs = np.copy(bin_begs[4:-4]); nbin_begs[0] = -np.inf;
nbin_counts = np.copy(bin_counts[4:-4]); 
nbin_counts[0] += np.sum(bin_counts[0:4]); 
nbin_counts[-1] += np.sum(bin_counts[-4:]);

# Note: I tried shifting emp_mean and emp_var locally, but p-value only decreased. So at least approx a local-max for G-test
fit_dist = sp.stats.norm(emp_mean,np.sqrt(emp_var));
normal_prob = [fit_dist.cdf(nbin_ends[i]) - fit_dist.cdf(nbin_begs[i]) for i in range(len(nbin_counts))];
emp_prob = nbin_counts / N;

gstat = np.sum(emp_prob * np.log(emp_prob/normal_prob))*2*N;
pval = sp.stats.chi2.sf(gstat, df = len(nbin_counts)-1);

print('Normality test:\n nbins = %d, Gstat = %g, pval = %g' % (len(nbin_counts), gstat, pval));


#
# Plot histogram and KDE
#
virtual_sample = [];
for i in range(len(bin_counts)):
    for j in range(int(bin_counts[i])):
        virtual_sample.append(bin_ends[i]);
hist1 = np.array(virtual_sample);
xmin = np.min(hist1); xmax = np.max(hist1);

ax = plt.figure().gca();
hh = ax.hist(hist1, bins=bin_ends, color='blue', normed=True, label='Histogram');
line = matplotlib.lines.Line2D(xdata=[emp_mean,emp_mean], ydata=[0,np.max(hh[0])], color='black', linewidth=3, linestyle='dashed');
plt.xlim([xmin,xmax]);
ax.add_line(line);
plt.title('Pearson crab data');
gkde = sp.stats.gaussian_kde(hist1);
Xs = np.linspace(xmin, xmax, 140);
ax.plot(Xs, gkde.pdf(Xs), color='red', linewidth=3, label='Density estimator');
#plt.savefig('../../figs/pearson_hist.svg', bbox_inches='tight');


ax.plot(Xs, fit_dist.pdf(Xs), color='green', linewidth=3, label='Fit normal');
plt.legend();
#plt.savefig('../../figs/pearson_hist_norm.svg', bbox_inches='tight');
plt.close();
    

#
# Plot qqplot
#
norm_quants = [fit_dist.ppf(i/N) for i in range(len(hist1))];
hist1.sort();
plt.plot(norm_quants, hist1, 'k.', label='Quantile-Quantile plot');
plt.plot([norm_quants[N//100], norm_quants[99*N//100]], [norm_quants[N//100], norm_quants[99*N//100]], color='blue', linewidth=3, linestyle='dashed', label='Ideal 1% to 99%');
plt.plot(norm_quants[N//4], norm_quants[N//4], marker='D', markersize=7.5, color='red');
plt.plot(norm_quants[3*N//4], norm_quants[3*N//4], marker='D', markersize=7.5, color='red');
plt.text(0.635, 0.625, '25 %');
plt.text(0.66, 0.65, '75 %');
plt.legend();
plt.title('Pearson crab data qqplot against fit normal');
plt.savefig('../../figs/pearson_qqplot.svg', bbox_inches='tight');
#plt.close();
