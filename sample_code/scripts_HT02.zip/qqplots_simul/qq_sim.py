def qqplot(s1, s2):
    if(len(s1) != len(s2)):
        print('Need equal-size samples, sorry.');
        return;

    s1.sort();
    s2.sort();
    N = len(s1);
    plt.figure();
    plt.plot(s1,s2, '.', color='black', markersize=7, label='Quantile-Quantile plot');

    # Draw quartile-quartile line
    l1 = s1[N//4]; l2 = s2[N//4];
    u1 = s1[3*N//4]; u2 = s2[3*N//4];
    vscale = u2-l2; hscale = u1 - l1;
    plt.plot(l1, l2, marker='D', color='red', markersize=10);
    plt.text(l1 + 0.1 * hscale, l2 - 0.2 * vscale, '25 %', fontsize=14);
    plt.plot(u1, u2, marker='D', color='red', markersize=10);
    plt.text(u1 + 0.1 * hscale, u2 - 0.2 * vscale, '75 %', fontsize=14);

    fit_qqline = lambda x: (x-l1) * (u2-l2)/(u1-l1) + l2;
    xmin = s1[N//100]; xmax = s1[99*N//100];
    Xs = np.linspace(xmin,xmax);
    plt.plot(Xs, fit_qqline(Xs), color='blue', linestyle='dashed', linewidth=3, label='Quartile fit');
    plt.legend();

Nsamp = 100;
dist1 = sp.stats.norm(loc=0, scale=1);
dist2 = sp.stats.norm(loc=0, scale=1);

qqplot(dist1.rvs(Nsamp), dist2.rvs(Nsamp));
plt.title('qqplot for normal vs normal. Nsamp = %d' % (Nsamp,));
plt.savefig('../../figs/qqplot_normnorm.svg', bbox_inches='tight');
plt.close();

Nsamp = 1000;
qqplot(dist1.rvs(Nsamp), dist2.rvs(Nsamp));
plt.title('qqplot for normal vs normal. Nsamp = %d' % (Nsamp,));
plt.savefig('../../figs/qqplot_normnorm2.svg', bbox_inches='tight');
plt.close();


Nsamp = 1000; tdf = 5;
dist1 = sp.stats.norm(loc=0, scale=1);
dist2 = sp.stats.chi2(df=tdf);

qqplot(dist1.rvs(Nsamp), dist2.rvs(Nsamp));
plt.title('qqplot for normal vs chi^2 (df=%d). Nsamp = %d' % (tdf, Nsamp,));
plt.savefig('../../figs/qqplot_normchi.svg', bbox_inches='tight');
plt.close();

