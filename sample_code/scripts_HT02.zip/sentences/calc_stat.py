import nltk


#novel = "MT_HuckleberryFinn.txt";
#novel = "MT_TomSawyer.txt";
def get_sentences(novel):
    fp = open(novel);
    data = fp.read();
    fp.close();
#    tokenizer = nltk.data.load('tokenizers/punkt/english.pickle');
#    allsent = tokenizer.tokenize(data);
    allsent = nltk.sent_tokenize(data);
    b = [len(it) for it in allsent];
    print('Got %d sentences from %s, mean = %g, std = %g\n' % (len(b), novel, np.mean(b), np.std(b)));
    return allsent;

def get_sentence_lenghts(novel):
    fp = open(novel);
    data = fp.read();
    fp.close();
#    tokenizer = nltk.data.load('tokenizers/punkt/english.pickle');
#    allsent = tokenizer.tokenize(data);
    allsent = nltk.sent_tokenize(data);
    b = [len(it) for it in allsent];
    print('Got %d sentences from %s, mean = %g, std = %g\n' % (len(b), novel, np.mean(b), np.std(b)));
    return b;

def get_random_senlengths(novel, size=1000):
    b = get_sentence_lenghts(novel);
    b2 = np.random.choice(b, size);
    print('Got %d random sentences from %s, mean = %g, std = %g\n' % (size, novel, np.mean(b2), np.std(b2)));
    return b2;


# Main script:
novel1 = 'MT_TomSawyer.txt';
novel2 = 'FD_Crime_and_punish.txt';
s2 = get_sentence_lenghts(novel1);
full_s2 = get_sentences(novel1);
s3 = get_sentence_lenghts(novel2);
full_s3 = get_sentences(novel2);

as2 = np.array(s2);
as3 = np.array(s3);
is2 = as2.argsort();
is3 = as3.argsort();

# 
# You can now print shortest/longest sequences:
# 


# Check normality of short sample-means:
#
a = []; b = []; samp_size = 300;
for i in range(2000):
    s3r = np.random.choice(s3,samp_size);
    a.append(np.mean(s3r));
    s2r = np.random.choice(s2,samp_size);
    b.append(np.mean(s2r));

anorm = (a - np.mean(a))/np.std(a);
bnorm = (b - np.mean(b))/np.std(b);

print('Testing normality of random %d-long sample means: \n %s:' % (samp_size, novel1) )
print(sp.stats.kstest(bnorm, 'norm'))
print('... and %s' % (novel2));
print(sp.stats.kstest(anorm, 'norm'))


# Compute t-statistic:
mean_tom = np.mean(s2);
mean_dost = np.mean(s3);
var_tom = np.var(s2,ddof=1); 
var_dost = np.var(s3, ddof=1);
n_tom = len(s2);
n_dost = len(s3);

plt.ioff(); 
plt.close();
plt.hist(s3, bins=40, normed=True); plt.title('%s. Mean = %g, std = %g' % (novel2, mean_dost, np.sqrt(var_dost)));
plt.savefig('sen_hist.svg');

plt.close();
plt.hist(b, bins=40, normed=True); plt.title('%s. Random %d-sample means' % (novel2,samp_size));
plt.savefig('sen_hist_smean.svg');

plt.close();
plt.hist((s2,s3), bins=40, normed=True, range=(0,600)); plt.title('Two novels'); plt.legend((novel1, novel2));
plt.savefig('sen_hist2.svg'); 

plt.close();
plt.hist((s2,s3), bins=40, normed=True, cumulative=True, range=(0,600)); plt.title('Two novels'); 
plt.savefig('sen_hist2_cdf.svg'); 

plt.close();
plt.hist((b,a), bins=40, normed=True, histtype='stepfilled', alpha=0.6); plt.title('Two novels. Random %d-sample means' % (samp_size));
plt.legend((novel1, novel2));
plt.savefig('sen_hist_smean2.svg');

print('Statistics: \n novel1 = %s, mean=%g, std=%g, n=%d\n novel2 = %s, mean=%g, std=%g, n=%d' 
        % (novel1, mean_tom, np.sqrt(var_tom), n_tom, novel2, mean_dost, np.sqrt(var_dost), n_dost));

tstat = (mean_tom - mean_dost)/np.sqrt(var_tom/n_tom + var_dost/n_dost);
pval = sp.stats.norm.sf(tstat);
print('Testing null "mean_dost > mean_tom": T-stat = %g, p-value = %g (normal approx)' % (tstat, pval));

if(tstat > 0):
    print('... Suggest to REJECT');
else:
    print('... Suggest to ACCEPT');


