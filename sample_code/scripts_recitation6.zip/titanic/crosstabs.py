import pandas as pd

def gstat_contingency(cta):
    cta_p1 = np.sum(cta,1)/np.sum(cta);
    cta_p0 = np.sum(cta,0)/np.sum(cta);

    cta_q = np.tensordot(cta_p1, cta_p0, axes=0);

    cta_p = cta / np.sum(cta);

    gstat = 2*np.sum(cta) * np.sum(cta_p*np.log(cta_p/cta_q));
    print('gstat = ', gstat);
    df_as = (cta.shape[0]-1)*(cta.shape[1]-1);
    gstat_p = sp.stats.chi2.sf(gstat, df=df_as);
    
    return gstat_p;

df = pd.DataFrame.from_csv('titanic_original.csv', index_col=2);

ct = pd.crosstab(df.survived, df.pclass);
print('Survived vs Ticket Class', ct);

cta = np.array(ct);

print('p-value (G-test for indep) = ', gstat_contingency(cta));

df2 = df[df.sex=='male'];
ct2 = pd.crosstab(df2.survived, df2.pclass);
print('Survived vs Ticket Class (males)', ct2);

ct2a = np.array(ct2)
print('p-value (G-test for indep) = ', gstat_contingency(ct2a));


#df3 = df[df.sex=='male'];
#pd.crosstab(df3.survived, df3.pclass);
